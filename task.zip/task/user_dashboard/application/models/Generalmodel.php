<?php

if (!defined('BASEPATH'))exit('No direct script access allowed');

class Generalmodel extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
    }

    function login($tablename, $email, $password)
    {          
		$this->db->where('email', $email);
        $this->db->where('password',sha1($password));
	    $this->db->from($tablename);			
		
        $result =  $this->db->get();
      
        if($this->db->affected_rows()>0)
        {
           $user =  $result->row();
           return $this->updateuser($tablename,$user); 
           
        }else{
            return false;
        }
    
    } 
    
    public function updateuser($tablename,$user)
    {
        if($this->db->where('id', $user->id)->update($tablename, array('logged_in_ever'=>1,'last_update'=>Date('Y-m-d')))){
            
            $sessionData = array('user_id'  => $user->id,
                             'fullName'     => $user->fullName,
                             'email'        => $user->email,
                             'isLoggedIn'   => true );
            return $sessionData;  
            
            }else{
            return false;
           }
    }
    public function add($tableName, $data) 
    {
        if($this->db->insert($tableName, $data)){
            return $this->db->insert_id();
        }else{
            return false;
        }
    }

    
  public function usersloggedInEverCount() 
  {
     
    $this->db->select('id');
    $this->db->from('user');
    $this->db->where('logged_in_ever', 1);
    $this->db->get();
    return $this->db->affected_rows();
    
  }
  public function getUsers(){
    
    $users = $this->db->select('fullName, email, mobile, last_update')->from('user')->where('logged_in_ever',1)->get()->result();
    if($users){
        return $users;
    }else{
        return false;
    }
  }
  public function getUserByEmail($email){
    
    $user = $this->db->select('id, fullName, email, mobile, last_update')->from('user')->where('email',$email)->get()->row();
    if($user){
        return $user;
    }else{
        return false;
    }
  } 
 
}
?>