<?php
set_include_path(get_include_path() . PATH_SEPARATOR . 'vendor/google/src');
require_once 'vendor/autoload.php';


defined('BASEPATH') or exit('No direct script access allowed');

class Home extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->config('google');

		$this->client_id  =  $this->config->item('client_id', 'google');
		$this->client_secret = $this->config->item('client_secret', 'google');
		$this->redirect_url =  $this->config->item('redirect_url', 'google');
	}


	public function index()
	{
  		$data['link']  = 'https://accounts.google.com/o/oauth2/v2/auth?scope=' . urlencode('https://www.googleapis.com/auth/userinfo.profile https://www.googleapis.com/auth/userinfo.email') . '&redirect_uri=' . urlencode($this->redirect_url) . '&response_type=code&client_id=' . $this->client_id . '&access_type=online';
 		$this->load->view('home', $data);
	}

	public function checkLoggedIn()
	{
		$isLoggedIn = $this->session->userdata('isLoggedIn');
		if (!$isLoggedIn) {
			redirect('Home');
		}
	}

	public function addUser()
	{
		//echo "<pre>"; print_r($_POST); exit;
		$this->form_validation->set_rules('fullName', 'Full Name', 'required');
		$this->form_validation->set_rules('email', 'Email', 'required');
		$this->form_validation->set_rules('password', 'Password', 'required');
		$this->form_validation->set_rules('mobile', 'Mobile Number', 'required');
		if ($this->form_validation == TRUE) {

			$data = array(
				'fullName' => $this->input->post('fullName'),
				'email' => $this->input->post('email'),
				'password' =>  sha1($this->input->post('password')),
				'mobile' => $this->input->post('mobile'),
				'status' => 1,
				'logged_in_ever' => 0,
				'created_at' => Date('Y-m-d')
			);

			$lastId = $this->Generalmodel->add('user', $data);

			if ($lastId) {
				$response['success'] = true;
				$response['message'] = "Registered successfully, please login!";
			} else {
				$response['success'] = false;
				$response['message'] = "Something worng. Try again.";
			}
		} else {
			$response['success'] = false;
			$response['message'] = "Please fill all the required fields!";
		}
		header('Content-Type: application/json; charset=utf-8', true);
		echo json_encode($response);
		exit;
	}

	public function loginUser()
	{
		$this->form_validation->set_rules('email', 'Email', 'required');
		$this->form_validation->set_rules('password', 'Password', 'required');
		if ($this->form_validation == TRUE) {
			if ($result = $this->Generalmodel->login('user', $this->input->post('email'), $this->input->post('password'))) {
				$this->session->set_userdata($result);
				$url = base_url() . 'index.php/dashboard';
				$response['success'] = true;
				$response['url'] = $url;
			} else {
				$response['success'] = false;
				$response['message'] = "Invalid email or passsword";
			}
		} else {
			$response['success'] = false;
			$response['message'] = "Enter email and passsword";
		}
		header('Content-Type: application/json; charset=utf-8', true);
		echo json_encode($response);
		exit;
	}
	public function google_auth()
	{
		if (isset($_GET['code'])) {

			$url = 'https://www.googleapis.com/oauth2/v4/token';
			$code = $_GET['code'];
			$curlPost = 'client_id=' . $this->client_id . '&redirect_uri=' . $this->redirect_url . '&client_secret=' . $this->client_secret . '&code=' . $code . '&grant_type=authorization_code';
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $curlPost);
			$response =  curl_exec($ch);
			$authObj = json_decode($response);
			$user_data = '';
			if (isset($authObj->access_token) && $authObj->access_token != '') {
				$user_data =  $this->get_google_user_email($authObj->access_token);
			} else {
				$this->session->set_flashdata('message', 'Access token not found');
				redirect('Home');
				exit;
			}
			if ($user_data) {

				$checkUser = $this->Generalmodel->getUserByEmail($user_data['email']);
				if ($checkUser) {
					$result = $this->Generalmodel->updateuser('user', $checkUser);
					$this->session->set_userdata($result);
					return redirect('/dashboard');
				} else {
					$data = array(
						'fullName' => $user_data['name'],
						'email' => $user_data['email'],
						'password' =>  sha1(rand(10000, 999999)),
						'mobile' => '',
						'status' => 1,
						'logged_in_ever' => 1,
						'created_at' => Date('Y-m-d'),
						'last_update' => Date('Y-m-d')
					);
					$lastId = $this->Generalmodel->add('user', $data);
					$sessionData = array(
						'user_id'  => $lastId,
						'fullName'     => $user_data['name'],
						'email'        => $user_data['email'],
						'isLoggedIn'   => true
					);
					$this->session->set_userdata($sessionData);
					return redirect('/dashboard');
				}
			} else {
				session_destroy();
				$this->session->set_flashdata('message', 'Invalid Login');
				redirect('Home');
				exit;
			}
		} else {
			session_destroy();
			$this->session->set_flashdata('message', 'Invalid Login');
			redirect('Home');
			exit;
		}
	}



	public function get_google_user_email($access_token)
	{

		$url = 'https://www.googleapis.com/oauth2/v2/userinfo?fields=name,email,gender,id,picture,verified_email';

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Authorization: Bearer ' . $access_token));
		$data = json_decode(curl_exec($ch), true);
		$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		if ($http_code == 200) {
			return $data;
		} else {
			return false;
		}
	}

	public function dashboard()
	{
		$this->checkLoggedIn();
		$data['totaluser'] = 0;
		$totalusers = $this->Generalmodel->usersloggedInEverCount();
		$data['totaluser'] = $totalusers;
		$data['username'] = $this->session->userdata('user_id');
		$this->load->view('dashboard', $data);
	}
	public function listVisitors()
	{
		$this->checkLoggedIn();
		$data['userList'] = '';
		$LoggedInEver = $this->Generalmodel->getUsers();
		$data['userList'] = $LoggedInEver;
		$this->load->view('listVisitors', $data);
	}
	public function logout()
	{
		session_unset();
		session_destroy();
		$data['link']  = 'https://accounts.google.com/o/oauth2/v2/auth?scope=' . urlencode('https://www.googleapis.com/auth/userinfo.profile https://www.googleapis.com/auth/userinfo.email') . '&redirect_uri=' . urlencode($this->redirect_url) . '&response_type=code&client_id=' . $this->client_id . '&access_type=online';
		$this->load->view('home', $data);
	}
	public function checkRegisteredEmail()
	{
		$email = $this->input->post('email');
 		$checkUser = $this->Generalmodel->getUserByEmail($email);
		 $response['success'] = '';
		 $response['message'] = "";
	 	if ($checkUser) {
				$response['success'] = true;
				$response['message'] = "Email already exists, try with another!";
			}
		header('Content-Type: application/json; charset=utf-8', true);
		echo json_encode($response);
		exit;	
	} 
    
}
