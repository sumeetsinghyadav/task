<!DOCTYPE html>
<html>
<head>
<title>User</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">

</head>
<style>
.input-group-addon {
   color: #fff;
   background-color: #337ab7;
}
 
.form-control, .input-group-addon {
   border-radius: 0px;
}
label{
  text-align: left !important;
}
.loginButton{
    padding-left: 75px;
    padding-right: 75px;
    padding-top: 8px;
    padding-bottom: 8px;
}
</style>