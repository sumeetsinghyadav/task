<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script>
    $(function() {
        $('#signupform').on('submit', function(e) {

            $(".warningMsg").css("display", "none");
            $(".successMsg").css("display", "none");

            e.preventDefault();
            var elem = $(this)
            $allIsOk = true;
            fullName = $(elem).find('input[name="fullName"]').val();
            email = $(elem).find('input[name="email"]').val();
            password = $(elem).find('input[name="password"]').val();
            mobile = $(elem).find('input[name="mobile"]').val();

            $(elem).find('input[name="fullName"]').css('border-color', '');
            $(elem).find('input[name="email"]').css('border-color', '');
            $(elem).find('input[name="password"]').css('border-color', '');

            if (fullName == '') {
                $allIsOk = false;
                $(elem).find('input[name="fullName"]').css('border-color', 'red');
            }
            if (email == '') {
                $allIsOk = false;
                $(elem).find('input[name="email"]').css('border-color', 'red');
            }
            if (password == '') {
                $allIsOk = false;
                $(elem).find('input[name="password"]').css('border-color', 'red');
            }
            if ($allIsOk == true) {
                $("#btn-signup").html("Please wait...");
                $("#btn-signup").prop("disabled", true);
                var url = '<?php echo base_url(); ?>index.php/register-user';
                $.ajax({
                    type: 'post',
                    url: url,
                    data: {
                        fullName: fullName,
                        email: email,
                        password: password,
                        mobile: mobile
                    },
                    success: function(response) {

                        if (response.success) {
                            $("#btn-signup").html("Sign Up");
                            $("#btn-signup").prop("disabled", false);
                            $(".successRegister").css("display", "block").html(response.message);
                            $("#signupform")[0].reset();
                            $('#signupbox').hide();
                            $('#loginbox').show();
                        } else {
                            $("#btn-signup").html("Sign Up");
                            $("#btn-signup").prop("disabled", false);
                            $(".warningMsg").css("display", "block").html(response.message);

                        }
                    }
                });
            }
        });

        $('#loginform').on('submit', function(e) {

            $(".errorLogin").css("display", "none");

            e.preventDefault();
            var elem = $(this)
            $allIsOk = true;
            email = $(elem).find('input[name="email"]').val();
            password = $(elem).find('input[name="password"]').val();

            $(elem).find('input[name="email"]').css('border-color', '');
            $(elem).find('input[name="password"]').css('border-color', '');

            if (email == '') {
                $allIsOk = false;
                $(elem).find('input[name="email"]').css('border-color', 'red');
            }
            if (password == '') {
                $allIsOk = false;
                $(elem).find('input[name="password"]').css('border-color', 'red');
            }

            if ($allIsOk == true) {
                $("#btn-login").html("Please wait...");
                $("#btn-login").prop("disabled", true);
                var url = '<?php echo base_url(); ?>index.php/login-user';
                $.ajax({
                    type: 'post',
                    url: url,
                    data: {
                        email: email,
                        password: password
                    },
                    success: function(response) {

                        if (response.success) {
                            $("#loginform")[0].reset();
                            window.location.href = response.url;

                        } else {
                            $("#btn-login").html('Login <i class="fa fa-sign-in" aria-hidden="true"></i>');
                            $("#btn-login").prop("disabled", false);
                            $(".errorLogin").css("display", "block").html(response.message);

                        }
                    }
                });
            }
        });


        $('.emailID').on('change', function(e) {
             email = $(".emailID").val();
              if (email!='') {
                var url = '<?php echo base_url(); ?>index.php/check-email';
                $.ajax({
                    type: 'post',
                    url: url,
                    data: {
                        email: email,
                    },
                    success: function(response) {

                        if (response.success) {
                            $(".emailID").val('');
                            $(".emailExists").css("display", "block").html(response.message);
                        } 
                    }
                });
            }
        });


    });
</script>