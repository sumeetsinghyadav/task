<?php defined('BASEPATH') OR exit('No direct script access allowed');

$config['google'] = Array(
  'client_id' => '392491595057-oraf79i3rp0javffvef2cjlo4etl07eg.apps.googleusercontent.com',
  'client_secret' => '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',
  'redirect_url' => "http://localhost/user_dashboard/index.php/home/google_auth",
  'api_key' =>'AIzaSyCx27XTkqzqu0Jfg4CAgB-pE9oWVzSRlH4'
 );
 